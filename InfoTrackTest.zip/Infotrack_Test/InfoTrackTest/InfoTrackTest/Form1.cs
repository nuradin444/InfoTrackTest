﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using InfoTrackTest.Models;

namespace InfoTrackTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            tb_SearchString.Text = null;
            tb_URLString.Text = null;
            rtb_ResultString.Text = null;
        }

        private async void btn_Search_Click(object sender, EventArgs e)
        {   //displays message on screen that the search is ongoing
            rtb_ResultString.Font = new Font(rtb_ResultString.Font,FontStyle.Italic);
            rtb_ResultString.Text = "one moment please....";
            try
            {
                InputValidation();

                var search_string = tb_SearchString.Text;
                var search_url = tb_URLString.Text;

                var searchobj = new SearchClient();
                var search_result = await searchobj.SearchGoogleAsync(search_string);

                var parser = new SearchParser();
                var listOfResults = parser.Search_ExtractClassR(search_result);

                var listofIndex = new List<int>();
                //loop through the results to find the result
                for(int x=0;x<listOfResults.Count;x++)
                {
                    if (listOfResults[x].Contains(search_url))
                        listofIndex.Add(x);
                }


                rtb_ResultString.Text = string.Empty;
                listofIndex.ForEach(x =>
                {
                    rtb_ResultString.Font = new Font(rtb_ResultString.Font, FontStyle.Regular);
                    if (rtb_ResultString.Text.Length == 0)
                        rtb_ResultString.Text = $"{x + 1}";
                    else
                        rtb_ResultString.Text += $", {x+1}";
                });
            }
            catch (Exception ex)
            {
                //This catches the exception on shows on screen the reason 
                rtb_ResultString.Font = new Font(rtb_ResultString.Font, FontStyle.Italic);
                rtb_ResultString.Text = $"Incorrect input was entered - \r\nReason:{ex.Message}";
                return;
            }

        }

        #region Helpers

        private bool InputValidation()
        {
            if (string.IsNullOrEmpty(tb_SearchString.Text))
                throw new Exception("Search string is null");

            if (tb_SearchString.Text.Any(x => !char.IsLetterOrDigit(x) && !char.IsWhiteSpace(x)))
                throw new Exception("Search string has special characters");

            if (string.IsNullOrEmpty(tb_URLString.Text))
                throw new Exception("URL String to match is empty");

            return true;
        }

        #endregion

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void rtb_ResultString_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
