﻿using System.Threading.Tasks;

namespace InfoTrackTest.Models
{
    public interface LinkingSearchClient
    { //carrying  over the google link
        Task<string> SearchGoogleAsync(string url);
    }
}
