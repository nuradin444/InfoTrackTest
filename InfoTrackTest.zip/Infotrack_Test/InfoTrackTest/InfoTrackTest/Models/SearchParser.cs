﻿using System;
using System.Collections.Generic;

namespace InfoTrackTest.Models
{
    public class SearchParser : FindSearchParser
    {   //structuring the resulted data thats returned 
        public List<string> Search_ExtractClassR(string google_answer)
        {
            var answer = new List<string>();
            //checks if the user has entered anything 
            if (string.IsNullOrEmpty(google_answer))
                return null;

            var i = 0;
            try
            {   //this makes the comparison of whats entered 
                while((i = google_answer.IndexOf("<h3 class=\"r\"", i)) != -1)
                {
                    var j = 0;
                    var check = google_answer.Substring(i);
                    while ((j = check.IndexOf("</h3>", j)) != -1)
                    {
                        var list = check.Substring(0, j + 5);
                        answer.Add(list);
                        break;
                    }
                    i++;
                }
                return answer;
            }
            catch(Exception ex)
            {
                throw new Exception($"Comparison Failed {ex.Message}");
            }
        }



    }
}
