﻿using System.Threading.Tasks;
using System.Net.Http;
using System;

namespace InfoTrackTest.Models
{
    public class SearchClient : LinkingSearchClient
    {    //url to find the result 
        public string googleurl = @"https://www.google.co.uk/search?num=100&q=land+registry+search";

        public async Task<string> SearchGoogleAsync(string text_Finder)
        {
            var link = create_link(text_Finder);

            try { 
            using (var httpclient = new HttpClient())
            {   
                var response = await httpclient.GetAsync(link);
                var content = await response.Content.ReadAsStringAsync();
                return content;
            }
            }
            //Any error appears by the user and this catches the exception 
            catch(Exception ex)
            { 
                throw new Exception($"HTTP Exception:{ex.Message}");
            }
        }
        //the returned url
        private string create_link(string search_text)
        {
            var url = "";
            search_text = search_text.Replace(' ', '+');
            url = googleurl.Replace("<search_string>", search_text);

            return url;
        }

    }
}
