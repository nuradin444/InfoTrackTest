﻿using System.Collections.Generic;

namespace InfoTrackTest.Models
{
    public interface FindSearchParser
    {
        List<string> Search_ExtractClassR(string search_result);
    }
}
