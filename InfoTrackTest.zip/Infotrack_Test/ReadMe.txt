please find the url rank finder i have done and included in this file.

When you enter visual studio press "start"
This will open up a web application where you can 
enter the string key word and url 
This will then return in the "Result" box 
the numbers you are looking for.

